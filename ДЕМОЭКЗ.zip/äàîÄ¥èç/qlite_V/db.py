
# ------------------------------------------------------------
# Работа с пользователями
# ------------------------------------------------------------
def get_user(cursor, login, password):
    """Поиск пользователя по логину и паролю."""
    query = """
        SELECT a.ид_клиента, a.фио, r.название_роли
        FROM Аккаунт a
        JOIN Роль r ON a.ид_роли = r.ид_роли
        WHERE a.логин = ? AND a.пароль = ?
    """
    cursor.execute(query, (login, password))
    row = cursor.fetchone()
    if not row:
        return None
    return {
        "id": row["ид_клиента"],
        "fio": row["фио"],
        "role": row["название_роли"]
    }


# ------------------------------------------------------------
# Справочники
# ------------------------------------------------------------
def get_categories(cursor):
    """Возвращает список всех категорий."""
    cursor.execute("SELECT название_категории FROM Категория ORDER BY название_категории")
    return [row["название_категории"] for row in cursor.fetchall()]


def get_suppliers(cursor):
    """Возвращает список всех поставщиков."""
    cursor.execute("SELECT название_поставщика FROM Поставщик ORDER BY название_поставщика")
    return [row["название_поставщика"] for row in cursor.fetchall()]


# ------------------------------------------------------------
# Товары
# ------------------------------------------------------------
def get_products(cursor, search="", category="Все категории", supplier="Все поставщики", sort_order=""):
    """
    Поиск и фильтрация товаров.
    Возвращает список строк (sqlite3.Row), каждая как словарь.
    """
    query = """
        SELECT p.ид_товара,
               p.наименование_товара,
               c.название_категории,
               p.описание_товара,
               p.производитель,
               s.название_поставщика,
               p.цена,
               p.количество_на_складе,
               p.действующая_скидка,
               p.фото,
               p.артикул,
               p.единица_измерения
        FROM Товар p
        JOIN Категория c ON p.ид_категории_товара = c.ид_категории_товара
        JOIN Поставщик s ON p.ид_поставщика = s.ид_поставщика
        WHERE 1 = 1
    """
    params = []

    if search:
        search_pattern = f"%{search.lower()}%"
        query += """
            AND (
                LOWER(p.наименование_товара) LIKE ? OR
                LOWER(p.артикул) LIKE ? OR
                LOWER(p.описание_товара) LIKE ? OR
                LOWER(p.производитель) LIKE ? OR
                LOWER(s.название_поставщика) LIKE ? OR
                LOWER(c.название_категории) LIKE ?
            )
        """
        params.extend([search_pattern] * 6)

    if category != "Все категории":
        query += " AND c.название_категории = ?"
        params.append(category)

    if supplier != "Все поставщики":
        query += " AND s.название_поставщика = ?"
        params.append(supplier)

    if sort_order == "По возраст.":
        query += " ORDER BY p.количество_на_складе ASC"
    elif sort_order == "По убыв.":
        query += " ORDER BY p.количество_на_складе DESC"
    else:
        query += " ORDER BY p.ид_товара ASC"

    cursor.execute(query, params)
    return cursor.fetchall()


def save_product(cursor, conn, prod_id, data_dict):
    """
    Добавление или обновление товара.
    prod_id – число (id существующего товара) или None для нового.
    data_dict – словарь с ключами: ид_категории_товара, ид_поставщика, артикул, наименование_товара, единица_измерения,
                цена, производитель, действующая_скидка, количество_на_складе, описание_товара, фото.
    """
    # Получаем id категории
    cursor.execute("SELECT ид_категории_товара FROM Категория WHERE название_категории = ?",
                   (data_dict.get("category", ""),))
    cat_row = cursor.fetchone()
    if not cat_row:
        raise ValueError(f"Категория '{data_dict.get('Категория')}' не найдена")

    # Получаем id поставщика
    cursor.execute("SELECT ид_поставщика FROM Поставщик WHERE название_поставщика = ?",
                   (data_dict.get("supplier", ""),))
    sup_row = cursor.fetchone()
    if not sup_row:
        raise ValueError(f"Поставщик '{data_dict.get('Поставщик')}' не найден")

    sql_params = (
        cat_row["ид_категории_товара"],
        data_dict.get("артикул", ""),
        data_dict.get("наименование_товара", ""),
        data_dict.get("единица_измерения", "шт."),
        float(data_dict.get("цена", 0)),
        sup_row["ид_поставщика"],
        data_dict.get("производитель", ""),
        int(data_dict.get("действующая_скидка", 0)),
        int(data_dict.get("количество_на_складе", 0)),
        data_dict.get("описание_товара", ""),
        data_dict.get("фото", "")
    )

    if prod_id:   # обновление существующего товара
        cursor.execute("""
            UPDATE Товар
            SET ид_категории_товара = ?,
                артикул = ?,
                наименование_товара = ?,
                единица_измерения = ?,
                цена = ?,
                ид_поставщика = ?,
                производитель = ?,
                действующая_скидка = ?,
                количество_на_складе = ?,
                описание_товара = ?,
                фото = ?
            WHERE ид_товара = ?
        """, sql_params + (prod_id,))
    else:         # новый товар
        cursor.execute("""
            INSERT INTO Товар (
                ид_категории_товара, артикул, наименование_товара, единица_измерения,
                цена, ид_поставщика, производитель, действующая_скидка,
                количество_на_складе, описание_товара, фото
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, sql_params)

    conn.commit()


def delete_product(cursor, conn, prod_id):
    """Удаление товара, если он не используется в заказах."""
    cursor.execute("SELECT COUNT(*) AS cnt FROM Деталь_Заказа WHERE ид_товара = ?", (prod_id,))
    order_count = cursor.fetchone()["cnt"]

    if order_count > 0:
        raise ValueError("Нельзя удалить товар, который присутствует в существующих заказах!")

    cursor.execute("DELETE FROM Товар WHERE ид_товара = ?", (prod_id,))
    conn.commit()